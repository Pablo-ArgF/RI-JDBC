UO283216 - Pablo Argallero Fernández
Exercise number 0 - Mechanic extended, payroll management and contract type management

-----------
I changed the tests as I indicated on the virtual campus' forum since they were passing the wrong parameter to the service impl 
on the "Delete payrolls" tests.

-----------
There was a problem on the last two cases of the "Update a contract type" that I tried to solve in a private
tutorship with Enrique that he said they were implemented correctly but they are not correctly saved in the bd.
He told me to try to solve them and after a lot of time researching for the cause I came up with the solution. 
The error was on the way the tests passed the dto to the transaction script. They passed a dto that had all the values
but the id of the contract type, that is why the update method didn't update the values on the db, because it could not find
the null id.

The solution was to get the id from the contract type we get in order to validate it existed and save it in the dto id value.
This way all tests pass green.

------------
There is also a problem in the "Find payrolls all scenarios" tests. This test suite is non detterministic since in some of the 
executions the tests are executed with no errors and in others errors appear.

This problem is caused by the floating point comparisson used in the tests. In order to fix it I rounded the values for the expected netWage
in the test to two cents using the Round.twoCents() method (the same way the netWage of the payrolls is calculated).
